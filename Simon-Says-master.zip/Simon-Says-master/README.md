# Simon-Says
Simon Says is a game created entirely in Java. It consists of a circle divided into 4 sections, each section contains a color that will light up and the user would have to follow that sequence of colors as long as possible.
